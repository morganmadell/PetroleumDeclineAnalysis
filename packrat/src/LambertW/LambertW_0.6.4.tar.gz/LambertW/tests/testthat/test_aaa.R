seed.tmp <- sample.int(1e5, 1)
cat("Seed used in testing", seed.tmp, "\n")
set.seed(seed.tmp)